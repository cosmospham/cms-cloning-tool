def test(str):
    print str