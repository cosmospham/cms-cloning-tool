HOST = '127.0.0.1'
DB_NAME = 'news'
USER_NAME = 'root'
PASSWORD = None
DEBUG = True
TABLE_PREFIX = 'ttbnews_'
UPLOAD_DIR = "H:\\www\\__new__\\ttbcms\\wp-content\\uploads\\"
UPLOAD_PATH = "/wp-content/uploads/"