from datetime import datetime
import time
# print datetime.now().strftime("%Y-%m-%d %H:%M:%S")
# print datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

ts = '2013-01-12 15:27:43'
f = '%Y-%m-%d %H:%M:%S'
d = datetime.strptime(ts, f)
now = datetime.now()

now = now.strftime(f) 
print now
now = time.localtime()
print now
print time.strftime(f, now)

# print datetime.utcfromtimestamp(ts)